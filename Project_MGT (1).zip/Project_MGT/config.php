<?php
	$con = mysqli_connect("localhost","root","","proj_mgt");
	if(!$con)
	{
		echo "No Connection";
	}
?>