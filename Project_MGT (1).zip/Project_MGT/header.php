<html>
	<head>
		<title>Project Mangement</title>
		<link rel="stylesheet" href="assets/css/bootstrap.css"/>
		<link rel="stylesheet" href="assets/css/toastr.css"/>
		<link rel="stylesheet" href="assets/css/fontawesome.css"/>
		<script src="assets/js/bootstrap.js"></script>
		<script src="assets/js/toastr.js"></script>
		<script src="assets/js/jquery.js"></script>
		<style>
			.float
			{
				position:fixed;
				width:60px;
				height:60px;
				bottom:40px;
				right:40px;
				color:#FFF;
				border-radius:50px;
				text-align:center;
				box-shadow: 2px 2px 3px #999;
			}
			.my-float
			{
				margin-top:8px;
			}
	</style>
	</head>